package it.csi.myprod.mycomp.presentation.mycomp.action;

/// NO OPERATION
public class NOPCommand implements ICommand {
	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	public NOPCommand() {

	}
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		return null;
	}
};
