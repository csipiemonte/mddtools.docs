package it.csi.myprod.mycomp.presentation.mycomp.action;

import java.util.*;

import it.csi.myprod.mycomp.dto.*;

/**
 * LogoutAction Action Class.
 *
 * @author GuiGen
 */
public class LogoutAction extends BaseAction {

	/**
	 * nessuna classe model associata
	 */
	public Class modelClass() {
		return null;
	}

	/**
	 * Mostra la pagina di conferma del logout
	 * @return SSO_LOGOUT.
	 */
	public String confirmLogout() throws Exception {
		return "confirmLogout";
	}

	/**
	 *
	 * @return SSO_LOGOUT.
	 */
	public String ssoLogout() throws Exception {

		log.debug("[LogoutAction::ssoLogout] START");

		invalidateLocalSession();
		log.debug("[LogoutAction::ssoLogout] START");
		return "SSO_LOGOUT";
	}

	/**
	 *
	 * @return LOCAL_LOGOUT.
	 */
	public String localLogout() throws Exception {

		log.debug("[LogoutAction::localLogout] START");
		invalidateLocalSession();
		log.debug("[LogoutAction::localLogout] START");
		return "LOCAL_LOGOUT";
	}

	protected void invalidateLocalSession() {
		/// NOP
	}

	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. 
	 */
	public void clearPageScopedAppData() {
		//NOP
	}

}
