package it.csi.myprod.mycomp.presentation.mycomp.security;
import java.util.Map;
import it.csi.myprod.mycomp.business.*;

public class ActorBasedUISecConstraint extends AbstractUISecConstraint {

	private final String actorCode;

	public ActorBasedUISecConstraint(String nomeContainer, String nomeWidget,
			int constrainedBehavior, boolean defaultState, String actorCode) {
		super(nomeContainer, nomeWidget, constrainedBehavior, defaultState);
		this.actorCode = actorCode;
	}

	@Override
	public boolean specificCheck(Map session, SecurityHelper sh)
			throws BEException {
		return sh.verifyCurrentUserForActor(session, actorCode);
	}

}
