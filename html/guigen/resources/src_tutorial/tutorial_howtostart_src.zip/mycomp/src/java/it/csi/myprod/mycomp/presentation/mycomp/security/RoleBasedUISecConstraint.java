package it.csi.myprod.mycomp.presentation.mycomp.security;
import java.util.Map;
import it.csi.myprod.mycomp.business.*;

public class RoleBasedUISecConstraint extends AbstractUISecConstraint {

	private final String roleCode;
	private final String domainCode;

	public RoleBasedUISecConstraint(String nomeContainer, String nomeWidget,
			int constrainedBehavior, boolean defaultState, String roleCode,
			String domainCode) {
		super(nomeContainer, nomeWidget, constrainedBehavior, defaultState);
		this.roleCode = roleCode;
		this.domainCode = domainCode;
	}

	@Override
	public boolean specificCheck(Map session, SecurityHelper sh)
			throws BEException {
		return sh.verifyCurrentUserForRole(session, roleCode, domainCode);
	}

}
