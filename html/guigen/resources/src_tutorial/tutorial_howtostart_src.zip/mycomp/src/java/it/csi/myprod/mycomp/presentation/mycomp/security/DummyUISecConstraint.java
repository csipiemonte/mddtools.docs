package it.csi.myprod.mycomp.presentation.mycomp.security;

import java.util.Map;
import it.csi.myprod.mycomp.business.*;

public class DummyUISecConstraint extends AbstractUISecConstraint {

	private final boolean _fixedValue;

	public DummyUISecConstraint(String nomeContainer, String nomeWidget,
			int constrainedBehavior, boolean defaultState, boolean fixedValue) {
		super(nomeContainer, nomeWidget, constrainedBehavior, defaultState);
		_fixedValue = fixedValue;
	}

	@Override
	public boolean specificCheck(Map session, SecurityHelper sh)
			throws BEException {
		return _fixedValue;
	}

}
