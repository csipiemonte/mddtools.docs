package it.csi.myprod.mycomp.business;

import java.util.*;

import it.csi.myprod.mycomp.dto.*;

import org.apache.log4j.*;
import it.csi.myprod.mycomp.util.*;

/*PROTECTED REGION ID(R-1534196706) ENABLED START*/

/*PROTECTED REGION END*/

public class BackEndFacade {

	/**  */
	protected static final Logger log = Logger
			.getLogger(Constants.APPLICATION_CODE + ".business");

	//////////////////////////////////////////////////////////////////////////////
	/// Costanti identificative degli Application Data
	//////////////////////////////////////////////////////////////////////////////

	public final static String APPDATA_CURRENTUSER_CODE = "appDatacurrentUser";

	//////////////////////////////////////////////////////////////////////////////
	/// Metodi associati alla U.I.
	/// - i metodi relativi a menu e azioni di inizializzazione sono direttamente 
	///   implementati in questa classe
	/// - i metodi relativi ai singoli content panel sono delegati nei rispettivi
	///   bean
	//////////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////////
	/// Property relative ai bean spring associati agli specifici content panel
	//////////////////////////////////////////////////////////////////////////////

	private it.csi.myprod.mycomp.business.home.CPBECpHome _CPBECpHome = null;

	public void setCPBECpHome(it.csi.myprod.mycomp.business.home.CPBECpHome bean) {
		_CPBECpHome = bean;
	}

	public it.csi.myprod.mycomp.business.home.CPBECpHome getCPBECpHome() {
		return _CPBECpHome;
	}

	//////////////////////////////////////////////////////////////////////////////
	/// Property aggiuntive del bean
	//////////////////////////////////////////////////////////////////////////////
	/*PROTECTED REGION ID(R-1264235389) ENABLED START*/
	//// inserire qui le property che si vogliono iniettare in questo bean (es. dao, proxy di pd, ...) 
	/*PROTECTED REGION END*/
}
