package it.csi.myprod.mycomp.presentation.mycomp.security;

import java.util.Map;
import it.csi.myprod.mycomp.business.*;

public class UCBasedUISecConstraint extends AbstractUISecConstraint {

	private final String useCaseCode;

	public UCBasedUISecConstraint(String nomeContainer, String nomeWidget,
			int constrainedBehavior, boolean defaultState, String useCaseCode) {
		super(nomeContainer, nomeWidget, constrainedBehavior, defaultState);
		this.useCaseCode = useCaseCode;
	}

	@Override
	public boolean specificCheck(Map session, SecurityHelper sh)
			throws BEException {
		return sh.verifyCurrentUserForUC(session, useCaseCode);
	}

}
