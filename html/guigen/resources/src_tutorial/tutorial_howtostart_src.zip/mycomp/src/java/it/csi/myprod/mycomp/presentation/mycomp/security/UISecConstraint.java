package it.csi.myprod.mycomp.presentation.mycomp.security;
import java.util.Map;
import it.csi.myprod.mycomp.business.*;

public interface UISecConstraint {

	public static final int ONOFF_CONSTRAINED_BEHAVIOR = 1;
	public static final int VISIB_CONSTRAINED_BEHAVIOR = 2;
	public boolean verifyConstraint(Map session, int checkedBehavior,
			SecurityHelper sh) throws BEException;
}
