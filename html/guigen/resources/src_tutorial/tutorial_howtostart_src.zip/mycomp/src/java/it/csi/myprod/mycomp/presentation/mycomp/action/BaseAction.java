package it.csi.myprod.mycomp.presentation.mycomp.action;

import java.util.*;
import java.lang.reflect.Method;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;

import org.apache.log4j.Logger;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.Preparable;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ActionSupport;

import it.csi.myprod.mycomp.util.*;
import it.csi.myprod.mycomp.dto.*;
import it.csi.myprod.mycomp.business.*;

import it.csi.myprod.mycomp.presentation.mycomp.security.*;

/**
 * Base Action che contiene gli elementi comuni all'applicazione.
 * Tutte le altre Action dell'applicazione dovranno ereditare da questa
 * in modo da ottenere le parti comuni, e dovranno implementare in proprio
 * le funzionalit&agrave; specifiche della pagina.
 * <p/>
 * La classe eredita da {@link com.opensymphony.xwork2.ActionSupport} i
 * metodi di utilit&agrave; necessari ad eseguire le principali operazioni
 * (ad esempio conversione, validazione, ecc...) ed implementa l'interfaccia
 * {@link org.apache.struts2.interceptor.SessionAware}, che permette
 * alla Action di accedere alla sessione. 
 * 
 * @author GuiGen
 */
public abstract class BaseAction extends ActionSupport
		implements
			SessionAware,
			Preparable {

	/**  */
	protected static final Logger log = Logger
			.getLogger(Constants.APPLICATION_CODE + ".presentation");

	/** Riferimento alla sessione corrente */
	protected Map session;

	public void setSession(Map session) {
		this.session = session;
	}
	public Map getSession() {
		return this.session;
	}

	protected Map<String, UISecConstraint> allMenuVisibilityConstraints = null;
	protected Map<String, UISecConstraint> allMenuOnOffConstraints = null;

	public void prepare() throws CommandExecutionException {

	}

	////////////////////////////////////////////////////////////////////////
	//// costruzione/lettura strato model da passare allo strato di logica
	////////////////////////////////////////////////////////////////////////
	public abstract Class modelClass();

	private java.lang.reflect.Method findReadMethod(String name, Class cl)
			throws IntrospectionException {
		name = (name.startsWith("get") || name.startsWith("set") ? name
				.substring(3) : name.startsWith("is")
				? name.substring(2)
				: name);
		BeanInfo bi = java.beans.Introspector.getBeanInfo(cl);
		PropertyDescriptor[] pds = bi.getPropertyDescriptors();
		for (int i = 0; i < pds.length; i++) {
			PropertyDescriptor currPd = pds[i];
			if (currPd.getName().equalsIgnoreCase(name))
				return currPd.getReadMethod();
		}
		return null;
	}

	private java.lang.reflect.Method findWriteMethod(String name, Class cl)
			throws IntrospectionException {
		name = (name.startsWith("get") || name.startsWith("set") ? name
				.substring(3) : name.startsWith("is")
				? name.substring(2)
				: name);
		BeanInfo bi = java.beans.Introspector.getBeanInfo(cl);
		PropertyDescriptor[] pds = bi.getPropertyDescriptors();
		for (int i = 0; i < pds.length; i++) {
			PropertyDescriptor currPd = pds[i];
			if (currPd.getName().equalsIgnoreCase(name))
				return currPd.getWriteMethod();
		}
		return null;
	}

	public Object toModel() {
		try {
			Object modelObj = modelClass().newInstance();
			// imposto prima di tutto la session per evitare errori nei setter
			// degli oggetti a scope Session
			((BaseSessionAwareDTO) modelObj).setSession(this.getSession());
			BeanInfo targetBI = java.beans.Introspector
					.getBeanInfo(modelClass());
			PropertyDescriptor[] targetPds = targetBI.getPropertyDescriptors();
			for (int i = 0; i < targetPds.length; i++) {
				PropertyDescriptor currTargetPD = targetPds[i];
				java.lang.reflect.Method srcReadMethod = findReadMethod(
						currTargetPD.getReadMethod().getName(), this.getClass());
				if (srcReadMethod != null) {
					Object srcVal = srcReadMethod.invoke(this, new Object[]{});
					java.lang.reflect.Method currWriteMethod = currTargetPD
							.getWriteMethod();
					if (currWriteMethod != null) {
						currTargetPD.getWriteMethod().invoke(modelObj,
								new Object[]{srcVal});
					}
				}
			}
			return modelObj;
		} catch (Exception e) {
			log.error(
					"[BaseAction::toModel] Errore interno nella costruzione del modello, classe:"
							+ modelClass() + ": " + e, e);
			throw new IllegalArgumentException(
					"Errore interno nella costruzione del modello, classe:"
							+ modelClass() + ": " + e);

		}
	}

	public void fromModel(Object modelObj) {
		try {
			BeanInfo srcBI = java.beans.Introspector.getBeanInfo(modelClass());
			PropertyDescriptor[] srcPds = srcBI.getPropertyDescriptors();
			for (int i = 0; i < srcPds.length; i++) {
				PropertyDescriptor currSrcPD = srcPds[i];
				java.lang.reflect.Method srcReadMethod = currSrcPD
						.getReadMethod();
				if (srcReadMethod != null) {
					Object srcVal = srcReadMethod.invoke(modelObj,
							new Object[]{});
					java.lang.reflect.Method targetWriteMethod = findWriteMethod(
							currSrcPD.getReadMethod().getName(), this
									.getClass());
					if (targetWriteMethod != null) {
						targetWriteMethod.invoke(this, new Object[]{srcVal});
					}
				}
			}
		} catch (Exception e) {
			log.error(
					"[BaseAction::fromModel] Errore interno nella costruzione del modello, classe:"
							+ modelClass() + ": " + e, e);
			throw new IllegalArgumentException(
					"Errore interno nella costruzione del modello, classe:"
							+ modelClass() + ": " + e);

		}
	}

	///////////////////////////////////
	/**
	 * Metodi per visibilita'/abilitazione dei Widget
	 */

	/**
	 * @return true se il widget deve essere reso visibile
	 */
	public boolean isWidgetVisible(String cpName, String widgShortName) {
		Map cpData = (Map) session.get(cpName);
		if (cpData != null) {
			Boolean visibleFlag = (Boolean) cpData.get(widgShortName
					+ "_visible");
			if (visibleFlag != null) {
				return visibleFlag.booleanValue();
			} else
				return true;
		} else
			return true;

	}

	/**
	 * @return true se il widget deve essere disabilitato
	 */
	public boolean isWidgetDisabled(String cpName, String widgShortName) {
		Map cpData = (Map) session.get(cpName);
		if (cpData != null) {
			Boolean enabledFlag = (Boolean) cpData.get(widgShortName
					+ "_enabled");
			if (enabledFlag != null) {
				return !enabledFlag.booleanValue();
			} else
				return false;
		} else
			return false;

	}

	///////////////////////////////////
	/**
	 * Metodi per visibilita'/abilitazione del menu
	 */

	static Map<String, List<String>> submenuMap = new HashMap<String, List<String>>();
	static {

	}

	/**
	 * @return true se il menu deve essere reso visibile
	 */
	public boolean isMenuVisible(String menuName) {
		return true;
	}

	/**
	 * @return true se almeno uno dei sottomenu del menu dato &egrave; vissibile, false altrimenti
	 */
	public boolean isAtLeastOneSubMenuVisible(String menuName) {

		return true;

	}

	/**
	 * @return true se il menu deve essere reso abilitato
	 */
	public boolean isMenuEnabled(String menuName) {

		return true;

	}

	/**
	 * @return true se il menu deve essere reso attivo (ovvero &grave; stato cliccato)
	 */
	public boolean isMenuActive(String menuName) {
		String menu = "menu_items_" + menuName;
		return menu.equals((String) session.get("active_menu"));
	}

	/**
	 * @return true se un sottomenu del menu dato (a qualunque livello) &egrave; attivo (ovvero &grave; stato cliccato)
	 */
	public boolean isSubMenuActive(String menuName) {
		List<String> subMenuList = submenuMap.get(menuName);
		if (subMenuList != null) {
			for (String subMenu : subMenuList) {
				if (isMenuActive(subMenu)) {
					return true;
				}
				if (isSubMenuActive(subMenu)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Gestione del reset della paginazione/sorting delle tabelle (Displaytag)
	 * @param tableName nome della tabella
	 * @return true se bisogna resettare paginazione/sorting, false altrimenti
	 */
	public boolean isTableClearStatus(String tableName) {
		String sessionValue = tableName + "_clearStatus";
		Boolean clearStatus = (Boolean) session.get(sessionValue);
		if (clearStatus == null) {
			clearStatus = true;
		}
		if (clearStatus) {
			// la proprieta' e' "usa e getta"
			session.put(sessionValue, Boolean.valueOf(false));
		}
		return clearStatus;
	}

	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. Deve essere implementato in tutte le sottoclassi associate
	 *  ad un content panel.
	 */
	public abstract void clearPageScopedAppData();

	/**
	 * Ripulisce gli eventuali errori di conversione se il metodo richiamato
	 * dichiarava @skipValidation 
	 */
	protected void clearConversionErrorsIfSkipValidation() {
		ActionContext ctx = ActionContext.getContext();
		String methodName = ctx.getActionInvocation().getProxy().getMethod();
		Method m;
		try {
			boolean skipValidation = true;
			m = this.getClass().getDeclaredMethod(methodName, new Class[]{});
			if (m != null) {
				skipValidation = m.isAnnotationPresent(SkipValidation.class);
			}
			if (skipValidation) {
				removeFailedParamsFromRequest(ctx);
				clearErrorsAndMessages();
			}
		} catch (SecurityException e) {
			log
					.error("[BaseAction::clearConversionErrorsIfSkipValidation] Errore interno: "
							+ e + ", ignoro");
		} catch (NoSuchMethodException e) {
			log
					.error("[BaseAction::clearConversionErrorsIfSkipValidation] Errore interno: "
							+ e + ", ignoro");
		}
	}

	private void removeFailedParamsFromRequest(ActionContext ctx) {
		ctx.getContextMap();
		ctx.getContextMap().remove("original.property.override");
	}

	private it.csi.myprod.mycomp.business.BackEndFacade _backEnd = null;

	public void setSpringBackEnd(it.csi.myprod.mycomp.business.BackEndFacade be) {
		_backEnd = be;
	}

	public it.csi.myprod.mycomp.business.BackEndFacade getSpringBackEnd() {
		return _backEnd;
	}

	private it.csi.myprod.mycomp.business.SecurityHelper _securityHelper = null;

	public void setSpringSecurityHelper(
			it.csi.myprod.mycomp.business.SecurityHelper sh) {
		_securityHelper = sh;
	}

	public it.csi.myprod.mycomp.business.SecurityHelper getSpringSecurityHelper() {
		return _securityHelper;
	}

}
